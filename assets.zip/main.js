const { app, BrowserWindow, ipcMain, desktopCapturer, screen } = require("electron");
app.commandLine.appendSwitch("disable-gpu");
app.commandLine.appendSwitch("disable-software-rasterizer");
app.disableHardwareAcceleration();

const path = require("path");
const { dialog } = require("electron");
const fetch = require("node-fetch");
const FormData = require("form-data");
const fs = require("fs");

let win;
let overlayWindow;
let timer = null;
let currentAuth = null;
let splash;
let overlayHideTimer = null;
let credentialsPath;


function saveCredentials(data) {
    try {
        fs.writeFileSync(credentialsPath, JSON.stringify(data));
    } catch (err) {
        console.error("Failed to save credentials:", err);
    }
}

function getSavedCredentials() {
    try {
        if (fs.existsSync(credentialsPath)) {
            return JSON.parse(fs.readFileSync(credentialsPath));
        }
    } catch (err) {
        console.error("Failed to read credentials:", err);
    }
    return null;
}

function clearCredentials() {
    try {
        if (fs.existsSync(credentialsPath)) {
            fs.unlinkSync(credentialsPath);
        }
    } catch (err) {
        console.error("Failed to clear credentials:", err);
    }
}

ipcMain.handle("auth:save", (event, data) => {
    saveCredentials(data);
    return { ok: true };
});

ipcMain.handle("auth:get", () => {
    return getSavedCredentials();
});

ipcMain.handle("auth:clear", () => {
    clearCredentials();
    return { ok: true };
});

/* =========================
   CREATE MAIN WINDOW
========================= */
function createWindow() {

    /* =========================
       SPLASH WINDOW
    ========================= */
    splash = new BrowserWindow({
        width: 400,
        height: 300,
        frame: false,
        alwaysOnTop: true,
        transparent: false,
        backgroundColor: "#1e1e2f",
        resizable: false,
        show: true
    });

    splash.loadFile(path.join(__dirname, "splash.html"));

    /* =========================
       MAIN WINDOW (HIDDEN)
    ========================= */
    win = new BrowserWindow({
        width: 1300,
        height: 800,
        show: false, // 🔥 important
        backgroundColor: "#1e1e2f",
        icon: path.join(__dirname, "assets", "icon.ico"),
        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
            partition: "persist:main"
        }
    });

    // ✅ Detect renderer crash
    win.webContents.on("render-process-gone", (event, details) => {
        console.error("Renderer crashed:", details);

        if (details.reason !== "clean-exit") {
            console.log("Reloading window after crash...");
            win.reload();
        }
    });

    // ✅ Detect unresponsive window
    win.webContents.on("unresponsive", () => {
        console.error("Window unresponsive — reloading...");
        win.reload();
    });


    let isQuitting = false;

    win.on("close", async (e) => {
        if (isQuitting) return;

        // If NOT tracking, close normally (no prompt)
        if (!timer) {
            isQuitting = true;
            app.quit();
            return;
        }

        // If tracking is running, confirm
        e.preventDefault();

        const choice = await dialog.showMessageBox(win, {
            type: "warning",
            buttons: ["Cancel", "Yes, Exit"],
            defaultId: 0,
            cancelId: 0,
            title: "Confirm Exit",
            message: "You are currently working.",
            detail:
                "If you close the app, you will be clocked out and work tracking will stop.\n\nAre you sure you want to exit?"
        });

        if (choice.response !== 1) return;

        isQuitting = true;

        // stop screenshots first (so it doesn't keep running during API call)
        stopTracking();

        // clock-out if needed (if already clocked-out, it will just pass)
        await clockOutIfNeeded(win);

        // clear storage (optional; keep if you want forced logout)
        try {
            await win.webContents.executeJavaScript(`
      localStorage.removeItem("token");
      localStorage.removeItem("user");
    `);
        } catch (err) { }

        app.quit();
    });





    win.removeMenu();

    const indexPath = app.isPackaged
        ? path.join(__dirname, "build", "index.html")
        : path.join(__dirname, "../build/index.html");

    win.loadFile(indexPath);

    /* =========================
       WHEN READY → SHOW APP
    ========================= */
    win.once("ready-to-show", () => {
        if (splash) {
            splash.destroy();
            splash = null;
        }

        win.show();
    });

    createOverlayWindow();
}



/* =========================
   CREATE OVERLAY WINDOW
========================= */
function createOverlayWindow() {
    const { width, height } = screen.getPrimaryDisplay().workAreaSize;

    overlayWindow = new BrowserWindow({
        width: 280,
        height: 210,
        x: width - 300,
        y: height - 230,
        frame: false,
        transparent: true,
        alwaysOnTop: true,
        skipTaskbar: true,
        resizable: false,
        focusable: false,
        show: false,
        webPreferences: {
            contextIsolation: false,
            nodeIntegration: true
        }
    });

    // Make overlay click-through
    overlayWindow.setIgnoreMouseEvents(true, { forward: true });

    // Use safe alwaysOnTop level
    overlayWindow.setAlwaysOnTop(true, "floating");


    overlayWindow.loadFile(path.join(__dirname, "overlay.html"));
}

app.whenReady().then(() => {
    credentialsPath = path.join(app.getPath("userData"), "auth.json");
    createWindow();
});

/* =========================
   CAPTURE SCREEN
========================= */
async function captureScreen() {
    const sources = await desktopCapturer.getSources({
        types: ["screen"],
        thumbnailSize: { width: 1366, height: 768 }
    });

    if (!sources.length) return null;

    const image = sources[0].thumbnail;

    // 🔥 Allow compositor to settle (important for RDP)
    await new Promise(resolve => setTimeout(resolve, 120));

    // 🔥 Generate JPEG only once
    const jpegBuffer = image.toJPEG(65);

    return {
        buffer: jpegBuffer,
        base64: jpegBuffer.toString("base64")
    };
}


/* =========================
   UPLOAD TO BACKEND
========================= */

async function uploadScreenshot(auth, buffer) {
    try {
        if (!auth?.apiBase || !auth?.token) return;

        const form = new FormData();

        form.append("screenshot", buffer, {
            filename: `ss_${Date.now()}.jpg`,
            contentType: "image/jpeg"
        });

        form.append("capturedAt", new Date().toISOString());

        const res = await fetch(`${auth.apiBase}/api/screenshots`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${auth.token}`,
                ...form.getHeaders()
            },
            body: form
        });

        // Optional: log non-200s
        if (!res.ok) {
            const txt = await res.text().catch(() => "");
            console.error("Screenshot upload failed:", res.status, txt);
        } else {
            console.log("Screenshot uploaded");
        }
    } catch (err) {
        console.error("Upload error:", err.message);
    }
}
function stopTracking() {
    if (timer) {
        clearTimeout(timer);
        timer = null;
    }

    try {
        if (overlayWindow && !overlayWindow.isDestroyed()) {
            overlayWindow.hide();
        }
    } catch (e) { }
}

async function clockOutIfNeeded(win) {
    try {
        // token from renderer
        const token = await win.webContents.executeJavaScript(
            `localStorage.getItem("token")`
        );

        // If no token, user isn't logged in → just close
        if (!token) return { didClockOut: false, reason: "no_token" };

        // apiBase: prefer currentAuth if tracking already started
        let apiBase = currentAuth?.apiBase;

        // fallback: store apiBase in localStorage from renderer (recommended)
        // if you already store it, this works:
        if (!apiBase) {
            apiBase = await win.webContents.executeJavaScript(
                `localStorage.getItem("apiBase")`
            );
        }

        if (!apiBase) {
            // If API base missing, still allow close
            return { didClockOut: false, reason: "no_apiBase" };
        }

        const res = await fetch(`${apiBase}/api/employee/attendance/clock-out`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        // ✅ If success → clocked out
        if (res.ok) return { didClockOut: true, reason: "ok" };

        // ✅ If already clocked out → allow close silently
        // (Different backends return different codes/messages)
        if ([400, 401, 403, 404, 409].includes(res.status)) {
            return { didClockOut: false, reason: `already_or_not_allowed_${res.status}` };
        }

        // Other errors: still allow closing (don’t trap user)
        const txt = await res.text().catch(() => "");
        console.error("Clock-out unexpected error:", res.status, txt);
        return { didClockOut: false, reason: `unexpected_${res.status}` };
    } catch (err) {
        console.error("Clock-out on close failed:", err.message);
        // Still close
        return { didClockOut: false, reason: "exception" };
    }
}

/* =========================
   START TRACKING
========================= */
// ipcMain.handle("ss:start", async (event, payload) => {

//     const { apiBase, token, intervalMs } = payload;

//     if (timer) clearInterval(timer);

//     currentAuth = { apiBase, token };

//     timer = setInterval(async () => {
//         try {
//             const result = await captureScreen();
//             if (!result) return;

//             console.log("Sending screenshot to overlay");

//             overlayWindow?.webContents.send("overlay-screenshot", result.base64);

//             overlayWindow?.show();
//             overlayWindow?.moveTop();

//             await uploadScreenshot(currentAuth, result.buffer);

//         } catch (err) {
//             console.error("Screenshot error:", err.message);
//         }
//     }, intervalMs || 60000);

//     return { ok: true };
// });

ipcMain.handle("ss:start", async (event, payload) => {
    const { apiBase, token } = payload;

    stopTracking(); // clear any existing timer

    currentAuth = { apiBase, token };

    // const MIN_DELAY = 6000;      // 1 minute
    // const MAX_DELAY = 90000;     // 15 minutes

    const MIN_DELAY = 50 * 60 * 1000;   // 50 minutes
    const MAX_DELAY = 70 * 60 * 1000;   // 70 minutes

    const scheduleNext = () => {
        const randomDelay =
            Math.floor(Math.random() * (MAX_DELAY - MIN_DELAY)) + MIN_DELAY;

        console.log(`Next screenshot in ${Math.round(randomDelay / 1000)} seconds`);

        timer = setTimeout(async () => {
            try {
                const result = await captureScreen();
                if (!result) {
                    scheduleNext();
                    return;
                }

                if (overlayWindow && !overlayWindow.isDestroyed()) {
                    overlayWindow.webContents.send("overlay-screenshot", result.base64);

                    if (!overlayWindow.isVisible()) {
                        overlayWindow.showInactive(); // show without focus steal
                    }
                    // Hide after 2 seconds
                    if (overlayHideTimer) {
                        clearTimeout(overlayHideTimer);
                    }

                    overlayHideTimer = setTimeout(() => {
                        if (overlayWindow && !overlayWindow.isDestroyed()) {

                            overlayWindow.hide();
                            overlayWindow.setIgnoreMouseEvents(true, { forward: true });

                        }
                    }, 2000);
                }
                uploadScreenshot(currentAuth, result.buffer)
                    .catch(err => console.error("Upload error:", err));


            } catch (err) {
                console.error("Screenshot error:", err.message);
            }

            // 🔥 Schedule next random capture
            scheduleNext();

        }, randomDelay);
    };

    scheduleNext();

    return { ok: true };
});

/* =========================
   STOP TRACKING
========================= */
// ipcMain.handle("ss:stop", async () => {
//     if (timer) clearInterval(timer);
//     timer = null;

//     overlayWindow?.hide();

//     return { ok: true };
// });
ipcMain.handle("ss:stop", async () => {
    stopTracking();
    return { ok: true };
});

/* =========================
   APP LIFECYCLE
========================= */
// app.on("window-all-closed", () => {
//     if (timer) clearInterval(timer);

//     if (process.platform !== "darwin") {
//         app.quit();
//     }
// });
app.on("window-all-closed", () => {
    if (timer) {
        clearTimeout(timer);
        timer = null;
    }

    if (process.platform !== "darwin") {
        app.quit();
    }
});
